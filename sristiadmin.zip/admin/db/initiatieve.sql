-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2020 at 10:38 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shibpmpw_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `initiatieve`
--

CREATE TABLE `initiatieve` (
  `id` int(11) NOT NULL,
  `p_id` int(20) NOT NULL,
  `date` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `place` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `short_description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `enrollment_no` int(20) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `initiatieve`
--

INSERT INTO `initiatieve` (`id`, `p_id`, `date`, `place`, `title`, `category`, `description`, `short_description`, `enrollment_no`, `file_name`, `uploaded_on`, `status`) VALUES
(9, 1222, 'scscfdsafdf', 'sfsfs', 'sfsffs', 's11', 'fdadfda', 'fddfdf', 0, '1.jpg', '2020-04-17 14:23:25', '1'),
(10, 456789, '12.03.2020', 'howrah', 'Test2', 's11', 'TestingWWWWWWWWWWWWWW', 'Short', 0, 'output-onlinepngtools.png', '2020-04-17 14:41:23', '1'),
(11, 255555, '20.12.2020', 'howrah', 'SHIKSHAN 3.0', 's12', 'We took a step forward to visit Uttar Shivnarayan Chawk Primary School on 12th March, 2016 to continue with our flagship project â€œShikshanâ€. This time around 12 members and volunteers were present to make this drive an immense success. Along with necessary educational stuffs we have had a great interactive session with them. We came to know about their hobbies and many other things. A motivational speech was also included in the session. Afterword we conducted a quiz contest. Total No. of Students: 72', 'We took a step forward to visit Uttar Shivnarayan Chawk Primary School on 12th March, 2016 to continue with our flagship project â€œShikshanâ€.', 0, 'shibpur_sristi_shikshan2_2-1.jpg', '2020-04-17 20:52:04', '1'),
(12, 4555555, '23.10.2020', 'howrah', 'Shikshan 2.0', '', 'Total 15 members and volunteers were participated. We distributed educational materials such as elementary books, exercise books, geometry box (only for class IV students) pen pencil and other necessary stuff. After distributing materials we conducted a motivational session and detailed survey. A quiz contest was also held and prizes were given accordingly. Total No. of Students: 126', 'Shikshan 2.0 is just another step for our educational initiative. After an initial survey we visited Paliarah Board Primary School on 27th February, 2016 for the main phase of project and detailed survey.', 10, 'shibpur_sristi_shikshan3_2.jpg', '2020-04-17 21:11:44', '1'),
(13, 11111, '1234', 'heaven', 'nope', 's11', '111', 'dsdsf', 1, '2020-08-18-4.jpg', '2020-10-21 06:22:05', '1'),
(14, 22222222, '12/2/20', 'heaven', 'test final', 's12', 'sdfsdfgsfgsfgsg', 'gdfjbndfgjgjbknfghknfgkfbfgbjd', 1, 'aaaaaaaa.png', '2020-11-01 10:06:36', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `initiatieve`
--
ALTER TABLE `initiatieve`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `initiatieve`
--
ALTER TABLE `initiatieve`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
