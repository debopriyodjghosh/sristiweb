-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2020 at 10:38 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shibpmpw_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `category` int(20) NOT NULL,
  `project_category` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `project_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `file_name`, `uploaded_on`, `status`, `category`, `project_category`, `project_name`) VALUES
(81, '04-17-2020_0320pm_30714251_1833299110048217_2786781339506966528_o.jpg', '0000-00-00 00:00:00', '1', 1, 'Test', '2020-04-17 15:20:09'),
(82, '04-17-2020_0320pm_57045362_2355624154482374_106162799759065088_o.jpg', '0000-00-00 00:00:00', '1', 1, 'Test', '2020-04-17 15:20:09'),
(83, '04-17-2020_0328pm_30714251_1833299110048217_2786781339506966528_o.jpg', '0000-00-00 00:00:00', '1', 3, 'a', '2020-04-17 15:28:38'),
(84, '04-17-2020_0332pm_57045362_2355624154482374_106162799759065088_o.jpg', '0000-00-00 00:00:00', '1', 4, 'B', '2020-04-17 15:32:24'),
(85, '04-17-2020_0334pm_images (1).jpg', '0000-00-00 00:00:00', '1', 5, 'C', '2020-04-17 15:34:57'),
(86, '04-17-2020_0341pm_download.jpg', '2020-04-17 15:41:46', '1', 9, 's13', 'G'),
(87, '04-17-2020_0822pm_2.jpg', '2020-04-17 20:22:03', '1', 10, 's13', 'test paridhan'),
(88, '04-17-2020_0822pm_3.jpg', '2020-04-17 20:22:03', '1', 10, 's13', 'test paridhan'),
(89, '04-17-2020_0822pm_4.jpg', '2020-04-17 20:22:03', '1', 10, 's13', 'test paridhan'),
(90, '10-21-2020_0620am_2020-08-18-6.jpg', '2020-10-21 06:20:07', '1', 1, 's11', 'test1234'),
(91, '11-01-2020_1015am_2020-08-18-1.jpg', '2020-11-01 10:15:58', '1', 0, 's12', 'test1234'),
(92, '11-01-2020_1015am_2020-08-18-2.jpg', '2020-11-01 10:15:58', '1', 0, 's12', 'test1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
