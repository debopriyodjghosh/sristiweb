
<?php
include_once 'header.php';
?>

<?php 
if(isset($_POST['submit'])){ 
    // Include the database configuration file 
    include_once 'db.php'; 
     
    // File upload configuration 
    $targetDir = "project_image/"; 
    $allowTypes = array('jpg','png','jpeg','gif'); 
    $p_id = $_POST['p_id'];
    $date = $_POST['date'];
    $place = $_POST['place'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $short_description = $_POST['short_description'];
    $enrollment_no = $_POST['enrollment_no'];
	
	
	
    echo $category;
    echo $p_id;
    echo $date;
    echo $place;
    echo $title;
    echo $category;
    echo $description;
    echo $short_description;
    echo $enrollment_no;
    
    
    
    
    
     
    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = ''; 
    $fileNames = array_filter($_FILES['files']['name']); 
    if(!empty($fileNames)){ 
        foreach($_FILES['files']['name'] as $key=>$val){ 
            // File upload path 
            $fileName = basename($_FILES['files']['name'][$key]); 
            $targetFilePath = $targetDir . $fileName; 
             
            // Check whether file type is valid 
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
            if(in_array($fileType, $allowTypes)){ 
                // Upload file to server 
                if(move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetFilePath)){ 
                    // Image db insert sql 
                    $insertValuesSQL .= "('".$fileName."','".$p_id."', '".$date."', '".$place."', '".$title."', '".$category."', '".$description."', '".$short_description."', '".$enrollment_no."',  NOW()),"; 
                }else{ 
                    $errorUpload .= $_FILES['files']['name'][$key].' | '; 
                } 
            }else{ 
                $errorUploadType .= $_FILES['files']['name'][$key].' | '; 
            } 
        } 
         
        if(!empty($insertValuesSQL)){ 
            $insertValuesSQL = trim($insertValuesSQL, ','); 
            // Insert image file name into database 
            $insert = $conn->query("INSERT INTO initiatieve (file_name, p_id, date, place, title, category, description, short_description, enrollment_no, uploaded_on) VALUES $insertValuesSQL"); 
            if($insert){ 
                $errorUpload = !empty($errorUpload)?'Upload Error: '.trim($errorUpload, ' | '):''; 
                $errorUploadType = !empty($errorUploadType)?'File Type Error: '.trim($errorUploadType, ' | '):''; 
                $errorMsg = !empty($errorUpload)?'<br/>'.$errorUpload.'<br/>'.$errorUploadType:'<br/>'.$errorUploadType; 
                $statusMsg = "Files are uploaded successfully.".$errorMsg; 
            }else{ 
                $statusMsg = "Sorry, there was an error uploading your file."; 
            } 
        } 
    }else{ 
        $statusMsg = 'Please select a file to upload.'; 
    } 
     
    // Display status message 
    echo $statusMsg; 
} 
?>


<form action="" method="post" enctype="multipart/form-data">
    <h2>Select Image Files to Upload:</h2>
	
    ADD Project ID:<input type="text" name="p_id"> <br>
    Project Date:<input type="text" name="date"> <br>
    Project Place:<input type="text" name="place"> <br>
    Project Title:<input type="text" name="title"> <br>
    Project Category:
                                        <select type="text" class="form-control" id="categoryName" placeholder="Product Name" name="category" >
											<option value="">~~SELECT Category~~</option>
											<?php 
											include_once 'db.php';
											$sql = "SELECT * FROM category ";
													$result = $conn->query($sql);

													while($row = $result->fetch_array()) {
														echo "<option value='".$row[1]."'>".$row[2]."</option>";
													} // while
													
											?>
										  </select> <br>
    ADD Description:<input type="text" name="description"><br>
    ADD Short Description:<input type="text" name="short_description"><br>
    <input type="file" name="files[]" multiple > <br>
    
    ADD Image Link:
                                        <select type="text" class="form-control" id="categoryName" placeholder="Product Name" name="enrollment_no" >
											<option value="">~~SELECT Project~~</option>
											<?php 
											include_once 'db.php';
											$sql = "SELECT * FROM images ";
													$result = $conn->query($sql);

													while($row = $result->fetch_array()) {
														echo "<option value='".$row[4]."'>".$row[6]."</option>";
													} // while
													
											?>
										  </select> <br>
    
    <input type="submit" name="submit" value="UPLOAD">
</form>


<?php
				include_once 'db.php';
				$result = mysqli_query($conn,"SELECT * FROM initiatieve");
				if (mysqli_num_rows($result) > 0) {
				?>
				  <table class="table">
				  
				  <thead class="thead-dark">
					<tr>
					  <th scope="col">ID</th>
					  <th scope="col">P_ID</th>
					  <th scope="col">DATE</th>
					  <th scope="col">PLACE</th>
					   <th scope="col">TITLE</th>
					<th scope="col">CATAGORY</th>
					<th scope="col">SHORT DESCRIPTION</th>
					<th scope="col">DESCRIPTION</th>
					<th scope="col">ENROLLMENT NO</th>
					 <th scope="col">FILE NAME</th>
					<th scope="col">UPLOADED ON</th>
					<th scope="col">STATUS</th>
					</tr>
				  </thead>
				<?php
				$i=0;
				while($row = mysqli_fetch_array($result)) {
				?>
				<tbody>
				<tr>
					<td><?php echo $row["id"]; ?></td>
					<td><?php echo $row["p_id"]; ?></td>
					<td><?php echo $row["date"]; ?></td>
					<td><?php echo $row["place"]; ?></td>
					<td><?php echo $row["title"]; ?></td>
					<td><?php echo $row["category"]; ?></td>
					<td><?php echo $row["description"]; ?></td>
					<td><?php echo $row["short_description"]; ?></td>
					<td><?php echo $row["enrollment_no"]; ?></td>
					<td><?php echo $row["file_name"]; ?></td>
					<td><?php echo $row["uploaded_on"]; ?></td>
					<td><?php echo $row["status"]; ?></td>

				</tr>
				</tbody>
				<?php
				$i++;
				}
				?>
				</table>
				 <?php
				}
				else{
					echo "No result found";
				}
				?>
				
				<?php
include_once 'footer.php';
?>
